//
//  Menu.swift
//  projetSwift
//
//  Created by Emilie Genton on 19/01/2021.
//

import UIKit

class Menu: UIViewController, UITextFieldDelegate {
    
      
    @IBOutlet weak var s_Mode: UISwitch!
    @IBOutlet weak var l_titre: UILabel!
    @IBOutlet weak var stackView_btns: UIStackView!
    
    var listePlaylists  : [Playlist] = []
    var listeBoutons : [UIButton] = []
    
    var tableauMusique: [Musique] = []
    var nomPlaylist = ""
    var numeroPlaylist = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let path = Bundle.main.path(forResource: "playlist_siames", ofType: "json")
        {
            print("je suis dans le premier if")
            if let str = try? String(contentsOfFile: path)
            {
                print("je suis dans le deuxième if")
                let rowData = Data(str.utf8)
                if let jsonData = try? JSONDecoder().decode(listePlaylist.self, from: rowData)
                {
                    listePlaylists = jsonData.mesPlaylist
                    
                    
                    /*for element in listePlaylists
                    {
                        print(element.nom," ",element.num)
                        for musique in element.getMesMusique()
                        {
                            print(musique.titre)
                        }
                    }
                    
                    print(listePlaylists.count)*/
                    
                }
            }
        }
        for element in listePlaylists
        {
            print(element.nom," ",element.num)
            for musique in element.getMesMusique()
            {
                print(musique.titre)
            }
        }
        
        print(listePlaylists.count)
        
        var i = 0
        for element in listePlaylists {
            let btn = UIButton(frame: CGRect(x: 5, y: 10+i, width: 350, height: 50))
            btn.setTitle(element.nom, for: .normal)
            btn.titleLabel?.font = UIFont.systemFont(ofSize: 30)
            btn.backgroundColor = UIColor.link
            btn.setTitleColor(UIColor.white, for: .normal)
            stackView_btns.addSubview(btn)
            i = i+80
            listeBoutons.append(btn)
        }
        i=0
        for element in listeBoutons {
            element.tag = i
            element.addTarget(self, action:#selector(clicBouton), for: .touchUpInside)
            i = i+1
        }
    }
    
    @objc
    func clicBouton(_ sender : UIButton){
        if let nouveau = self.storyboard?.instantiateViewController(withIdentifier: "EditViewControllerID") as? EditViewController
        {
            nouveau.mesMusiques = listePlaylists[sender.tag]
            self.present(nouveau, animated: true, completion: nil)
            navigationController?.pushViewController(nouveau, animated: true)
        }
        
        
        
        
        
    }
    
  lazy var playlist1 = Playlist(mesMusiques: tableauMusique, nom: nomPlaylist, num: numeroPlaylist)
    
    
    @IBAction func changerMode(_ sender: Any) {
        //mode clair
       if( s_Mode.isOn == false)
       {
            view.backgroundColor=UIColor(red: 255, green: 255, blue: 255, alpha: 1)
            view.backgroundColor = UIColor(red: 255, green: 255, blue: 255, alpha: 1)
            l_titre.textColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
       }
       //mode sombre
       else{
            
            view.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
            l_titre.textColor = UIColor(red: 255, green: 255, blue: 255, alpha: 1)
            s_Mode.onTintColor = UIColor.link
       }
    }
    
    
  
}
