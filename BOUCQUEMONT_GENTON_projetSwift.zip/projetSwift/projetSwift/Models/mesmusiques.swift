//
//  musique.swift
//  projetSwift
//
//  Created by Emilie Genton on 20/01/2021.
//

import Foundation

//MARK: - MaListeMusiques
class Playlist:Codable {
    var mesMusiques : [Musique]
    var nom : String
    var num : Int
    
    init(mesMusiques : [Musique], nom: String, num: Int) {
        self.mesMusiques = mesMusiques
        self.num = num
        self.nom = nom
    }
    
    func ajouterMusique(maMusique : Musique)
    {
        self.mesMusiques.append(maMusique)
    }
    
    func supprimerMusique(index: Int ) {
        self.mesMusiques.remove(at: index)
    }
    
    func getMesMusique() -> [Musique]{
        return self.mesMusiques
    }
    
}

//MARK: - Musique
class Musique:Codable {
    var titre: String
    var descriptif: String
    var fichierAudio: String
    var image: String
    
    
    init(titre : String, descriptif : String, fichierAudio :String, image : String) {
        self.titre = titre
        self.descriptif = descriptif
        self.fichierAudio = fichierAudio
        self.image = image
    }
    
    func afficherMusique()->String {
        return "Titre : \(self.titre)"
    }
    
}


class listePlaylist:Codable {
    var mesPlaylist : [Playlist]
    init(mesPlaylist : [Playlist]) {
        self.mesPlaylist = mesPlaylist
    }
    
    func getPlaylist(index : Int)->Playlist
    {
        return mesPlaylist[index]
    }
    
}
