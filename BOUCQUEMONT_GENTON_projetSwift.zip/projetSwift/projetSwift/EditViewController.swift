//
//  ViewController.swift
//  projetSwift
//
//  Created by Emilie Genton on 05/01/2021.
//

import UIKit
import AVFoundation

class EditViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    var maMusique : Musique?
    var mesMusiques : Playlist?
 
    var titreChansons : [String] = [] 
    var player:AVAudioPlayer?
    var positionCurseur = 0.0
    var timer = Timer()
    var titre = ""
    var descriptif = ""
    var image = ""
    var chemin = ""
    var descriptifTextes : [String] = []
    var listeImage : [UIImage?] = []
    var listeAudio : [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        p_choix_chanson.delegate =  self
        p_choix_chanson.dataSource = self
        
        btn_play.isEnabled=true
        btn_pause.isEnabled=false
        
       
        s_slider.minimumValue = 0.0
        
        //récupérations des données du fichier json
        if let musiques=mesMusiques {
             print(mesMusiques?.getMesMusique().count)
             for element in mesMusiques!.getMesMusique() {
                 titreChansons.append(element.titre)
                 descriptifTextes.append(element.descriptif)
                 listeImage.append(UIImage(named: element.image))
                 listeAudio.append(element.fichierAudio)
                 
             }
             l_titre.text = titreChansons[0]
             t_descriptif.text = descriptifTextes[0]
             i_image.image = listeImage[0]
            
            let path = Bundle.main.path(forResource: listeAudio[0], ofType: "mp3")!
            let url = URL(fileURLWithPath: path)
            
            do {
                player = try AVAudioPlayer(contentsOf: url)
                
            }
            catch{
                print("ERREUR : fichier non trouvé")
            }
            
            if(player != nil){
                positionCurseur = player!.currentTime
                s_slider.maximumValue = Float(player!.duration)
                l_dureeMusique.text = afficherDureeMusique()
            }
         
        }
        
       
        
        if let path = Bundle.main.path(forResource: "mesmusiques", ofType: "json")
        {
            if let str = try? String(contentsOfFile: path)
            {
                let rowData = Data(str.utf8)
                print("Row data : ",rowData)
                if let jsonData = try? JSONDecoder().decode(Musique.self, from: rowData)
                {
                    titre = jsonData.titre
                    descriptif = jsonData.descriptif
                    image = jsonData.image
                    chemin = jsonData.fichierAudio
                }
                else{
                    print("No JSON data")
                }
            }
        }
        
     
        
        
    }

    @IBOutlet weak var btn_volume: UIButton!
    @IBOutlet weak var btn_avant: UIButton!
    @IBOutlet weak var btn_pause: UIButton!
    @IBOutlet weak var btn_play: UIButton!
    @IBOutlet weak var btn_apres: UIButton!
    @IBOutlet weak var s_Mode: UISwitch!
    
    @IBOutlet weak var l_titre: UILabel!
    @IBOutlet weak var s_slider: UISlider!
    @IBOutlet weak var t_descriptif: UITextView!
    @IBOutlet weak var i_image: UIImageView!
    @IBOutlet weak var p_choix_chanson: UIPickerView!
    @IBOutlet weak var l_dureeMusique: UILabel!
   
    @IBOutlet weak var s_sliderSon: UISlider!
    
    //Actions boutons
   
    
    @IBAction func chansonPause(_ sender: UIButton) {
        if (player != nil) {
            player!.pause()
            btn_play.isEnabled=true
            btn_pause.isEnabled=false
        }
        else {
            print("le player est à nil")
        }
    }
    
    @IBAction func chansonPlay(_ sender: UIButton) {
        if (player != nil) {
            player!.play()
            if (player!.isPlaying)
            {
                                
                timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
                timer.fire()
                btn_play.isEnabled=false
                btn_pause.isEnabled=true
                
                
              
            }
            
        }
        else {
            print("le player est à nil")
        }
    }
    
    @objc func updateTimer() {
        
        /*if(s_slider.value != Float(player!.currentTime))
        {
            
            player!.play(atTime: TimeInterval(s_slider.value))
            
        }
        else {
            s_slider.value = Float(player!.currentTime)
            
            
            UIView.animate(withDuration: player!.duration)
            {
                self.s_slider.setValue(self.s_slider.value, animated: true)
            }
            l_dureeMusique.text = afficherDureeMusique()
            
        }*/
        
        
        // marche a ne pas enlever x)
        s_slider.value = Float(player!.currentTime)
        UIView.animate(withDuration: player!.duration)
        {
            self.s_slider.setValue(self.s_slider.value, animated: true)
        }
        l_dureeMusique.text = afficherDureeMusique()
        
       
    }
    
    @IBAction func chansonApres(_ sender: UIButton) {
        
        actualRow = actualRow + 1
        
        if(actualRow>=listeAudio.count)
        {
            actualRow=0
        }
        miseAJourComposants(row: actualRow)
        
        p_choix_chanson.dataSource = self
        p_choix_chanson.delegate = self
        p_choix_chanson.selectRow(actualRow, inComponent: 0, animated: true)
    }
    
    @IBAction func chansonAvant(_ sender: UIButton) {
        actualRow = actualRow - 1
        if(actualRow<0)
        {
            actualRow=listeAudio.count-1
        }
        miseAJourComposants(row: actualRow)
        
        p_choix_chanson.dataSource = self
        p_choix_chanson.delegate = self
        p_choix_chanson.selectRow(actualRow, inComponent: 0, animated: true)
        
    }
    
    
    //SWITCH Mode SOMBRE ou CLAIR
    @IBAction func changerMode(_ sender: Any) {
        //mode clair
       if( s_Mode.isOn == false)
       {
            view.backgroundColor=UIColor(red: 255, green: 255, blue: 255, alpha: 1)
            view.backgroundColor = UIColor(red: 255, green: 255, blue: 255, alpha: 1)
            l_titre.textColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
            l_dureeMusique.textColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
            t_descriptif.textColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
            t_descriptif.backgroundColor = UIColor(red: 255, green: 255, blue: 255, alpha: 1)
        
            p_choix_chanson.backgroundColor = UIColor(red: 255, green: 255, blue: 255, alpha: 1)
            p_choix_chanson.setValue(UIColor.black, forKeyPath: "textColor")
       }
       //mode sombre
       else{
            
            view.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
            l_titre.textColor = UIColor(red: 255, green: 255, blue: 255, alpha: 1)
            l_dureeMusique.textColor = UIColor(red: 255, green: 255, blue: 255, alpha: 1)
            t_descriptif.textColor = UIColor(red: 255, green: 255, blue: 255, alpha: 1)
            t_descriptif.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
        
            p_choix_chanson.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
            p_choix_chanson.setValue(UIColor.white, forKeyPath: "textColor")
            s_Mode.onTintColor = UIColor.link
       }
    }
    
    
    //Picker view des musiques
    //let titreChansons = ["Clint Eastwood", "Mr Fear", "Bad Liar"]
   
    
    
    

    
    var actualRow = 0
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return titreChansons.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int ) -> String? {
        return titreChansons[row]
    }
   
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        miseAJourComposants(row: row)
    }
    

    

    
    func afficherDureeMusique() -> String {
        let minutes1 = Float(player!.currentTime)/60
        let secondes1 = Float(player!.currentTime).truncatingRemainder(dividingBy: 60)
        
        let minutes = Float(player!.duration)/60
        let secondes = Float(player!.duration).truncatingRemainder(dividingBy: 60)
        
        return String(format: "%02d:%02d",Int(minutes1),Int(secondes1)) + " / " + String(format: "%02d:%02d",Int(minutes),Int(secondes))
    }
    
    
    ///
    func miseAJourComposants(row: Int)
    {
   
        l_titre.text = titreChansons[row]
        t_descriptif.text = descriptifTextes[row]
        i_image.image = listeImage[row]
        actualRow = row
        
        let path = Bundle.main.path(forResource: listeAudio[row], ofType: "mp3")!
        let url = URL(fileURLWithPath: path)
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            
        }
        catch{
            print("ERREUR : fichier non trouvé")
        }
        l_dureeMusique.text = afficherDureeMusique()
    }
    
    var sonCouper = false
    var sonSauvegarde : Float = 0.0
    ////////////////Gestion du son
    @IBAction func gestionSon(_ sender: Any) {
        
        if(sonCouper == false){
            sonCouper=true
            sonSauvegarde = s_sliderSon.value
            s_sliderSon.value = 0
            player?.volume=0
            let image = UIImage(systemName: "volume.slash.fill")
            btn_volume.setImage(image, for: .normal)
            btn_volume.setTitle("", for: .normal)
            btn_volume.setTitleColor(UIColor.link, for: .normal)
        }
        else{
            var image = UIImage(systemName: "volume.1.fill")
            
            if(sonSauvegarde == 1)
            {
                image = UIImage(systemName: "volume.3.fill")
            }
                       
            sonCouper=false
            btn_volume.setImage(image, for: .normal)
            btn_volume.setTitle("", for: .normal)
            btn_volume.setTitleColor(UIColor.link, for: .normal)
            
            s_sliderSon.value = sonSauvegarde
            player?.volume=sonSauvegarde
        }
    }
    
    @IBAction func sliderSon(_ sender: Any) {
        let valueslider = s_sliderSon.value
        player?.volume=valueslider
        
        if(valueslider == 0)
        {
            let image = UIImage(systemName: "volume.slash.fill")
            btn_volume.setImage(image, for: .normal)
            btn_volume.setTitle("", for: .normal)
            btn_volume.setTitleColor(UIColor.link, for: .normal)
            sonCouper=true
        }
        else if(valueslider == 1){
            let image = UIImage(systemName: "volume.3.fill")
            btn_volume.setImage(image, for: .normal)
            btn_volume.setTitle("", for: .normal)
            btn_volume.setTitleColor(UIColor.link, for: .normal)
            sonCouper = false
        }
        else
        {
            let image = UIImage(systemName: "volume.1.fill")
            btn_volume.setImage(image, for: .normal)
            btn_volume.setTitle("", for: .normal)
            btn_volume.setTitleColor(UIColor.link, for: .normal)
            sonCouper = false
            
        }
    }
    
}

